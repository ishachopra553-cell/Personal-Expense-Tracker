from flask import Flask, render_template, request, jsonify
import joblib
import warnings
import matplotlib
matplotlib.use('Agg')  # For server side plotting
import matplotlib.pyplot as plt
import numpy as np
import os
import base64
from io import BytesIO

warnings.filterwarnings("ignore", category=UserWarning)


app = Flask(__name__)

# Load trained Apple model
model = joblib.load("model.pkl")  # Trained on Apple (AAPL) stock data

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form values
        open_price = float(request.form['open'])
        high = float(request.form['high'])
        low = float(request.form['low'])

        features = [[open_price, high, low]]

        # Prediction
        prediction = model.predict(features)

# Safely extract value from numpy array
        prediction_value = float(prediction.flatten()[0])
        prediction_value = round(prediction_value, 2)


        # Generate graph with proper labels
        labels = ['Open', 'High', 'Low', 'Predicted Close']
        values = [open_price, high, low, prediction_value]

        plt.figure(figsize=(6,4))
        bars = plt.bar(labels, values, color=['blue','green','red','orange'])
        plt.title("Apple (AAPL) Stock Prediction")
        plt.ylabel("Price ($)")
        plt.grid(axis='y', linestyle='--', alpha=0.7)

        # Add value labels on top of bars
        for bar in bars:
            yval = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2, yval + 0.5, round(yval, 2), ha='center', va='bottom', fontsize=10)

        plt.tight_layout()

        # Save plot to PNG in memory
        img = BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        graph_url = base64.b64encode(img.getvalue()).decode()
        plt.close()

        return render_template("index.html", prediction=prediction_value, graph_url=graph_url)

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        })

if __name__ == "__main__":
    app.run(debug=True)
